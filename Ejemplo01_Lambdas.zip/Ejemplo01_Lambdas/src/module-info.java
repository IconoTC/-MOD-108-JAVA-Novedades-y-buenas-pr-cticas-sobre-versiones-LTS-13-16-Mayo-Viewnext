/**
 * 
 */
/**
 * 
 */
module Ejemplo01_Lambdas {
}