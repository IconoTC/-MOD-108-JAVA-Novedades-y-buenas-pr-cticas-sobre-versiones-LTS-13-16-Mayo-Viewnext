package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis de lambda:   parametros -> cuerpo de la funcion
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros se necitan parentesis
		// No es obligatorio poner el tipo a los parametros
		ItfzFuncional lambda1 = (nom, e) -> "nombre: " + nom + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 36));
		
		ItfzFuncional lambda2 = (String nombre, int edad) -> "nombre: " + nombre + " edad: " + edad;
		System.out.println(lambda2.infoPersonas("Pepito", 36));
		
		// Por defecto el lambda retorna el valor sin necesidad de poner return
		// Si ponemos return debe ir el cuerpo entre llaves
		ItfzFuncional lambda3 = (nombre, edad) -> {
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 36));
		
		ItfzFuncional lambda4 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 36));
		
		// Inferencia de tipos
		ItfzFuncional lambda5 = (var nombre, var edad) -> "nombre: " + nombre + " edad: " + edad;
		System.out.println(lambda5.infoPersonas("Pepito", 36));
	}

}
