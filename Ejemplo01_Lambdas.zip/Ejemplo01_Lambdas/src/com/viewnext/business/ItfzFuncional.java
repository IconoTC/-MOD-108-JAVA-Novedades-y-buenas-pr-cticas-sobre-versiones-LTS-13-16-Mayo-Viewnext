package com.viewnext.business;

// Es una interface funcional porque solo tiene un metodo abstracto
@FunctionalInterface
public interface ItfzFuncional {
	
	String infoPersonas(String nombre, int edad);
	

}
