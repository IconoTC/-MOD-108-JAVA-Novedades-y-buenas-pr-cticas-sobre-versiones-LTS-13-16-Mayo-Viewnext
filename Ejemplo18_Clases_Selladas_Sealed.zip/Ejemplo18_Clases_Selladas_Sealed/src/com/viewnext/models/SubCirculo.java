package com.viewnext.models;

public non-sealed class SubCirculo extends Circulo{

}
