package com.viewnext.models;

// Una clase heradada de otra clase sealed, debe declararse como:
// 	-final; no podremos heredar de ella
// 	-non-sealed; puede tener tantas subclases como se quiera
// 	-sealed; puede tener subclases pero solo las permitidas


//public final class Circulo extends Figura {
//public non-sealed class Circulo extends Figura {
public sealed class Circulo extends Figura permits SubCirculo{

	private double radio;

	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(int x, int y, double radio) {
		super(x, y);
		this.radio = radio;
	}

	@Override
	double calcularArea() {
		return Math.PI * Math.pow(radio, 2);
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Circulo [radio=" + radio + ", toString()=" + super.toString() + "]";
	}
	
	

}
