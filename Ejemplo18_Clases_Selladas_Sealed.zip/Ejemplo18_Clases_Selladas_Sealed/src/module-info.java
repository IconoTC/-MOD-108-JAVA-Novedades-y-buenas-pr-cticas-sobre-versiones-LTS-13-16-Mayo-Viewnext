/**
 * 
 */
/**
 * 
 */
module Ejemplo18_Clases_Sealed {
}