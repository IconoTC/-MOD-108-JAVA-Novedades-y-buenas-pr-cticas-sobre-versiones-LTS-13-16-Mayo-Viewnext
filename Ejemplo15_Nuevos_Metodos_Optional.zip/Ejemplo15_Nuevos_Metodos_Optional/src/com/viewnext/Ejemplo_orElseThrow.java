package com.viewnext;

import java.util.Optional;

public class Ejemplo_orElseThrow {

	public static void main(String[] args) {
		
		//Optional<String> optionalValue = Optional.ofNullable(null);
		Optional<String> optionalValue = Optional.ofNullable("Hola");
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no, mostraremos el valor 
		String value = optionalValue.orElseThrow(() -> new IllegalStateException("Valor nulo") );
		System.out.println("Valor: " + value);

	}

}
