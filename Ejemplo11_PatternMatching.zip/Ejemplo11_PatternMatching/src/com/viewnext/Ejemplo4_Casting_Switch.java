package com.viewnext;

public class Ejemplo4_Casting_Switch {

	public static void main(String[] args) {
		
		Object dato = "Pepito Perez";
		
		int resultado = switch(dato) { 
		
			// Casting automatico dentro de los switch pertenece a Java 21
			case String texto -> {	  
				System.out.println("Esto es un texto");
				yield texto.length();
			}
			
			case Integer numero -> {
				System.out.println("Esto es un numero");
				yield ++numero;
			}
			default -> {
				throw new IllegalArgumentException("Unexpected value: " + dato);
			}
		};
		
		System.out.println("Resultado: " + resultado);

	}

}
