package com.viewnext;

public class Ejemplo3_Switch_Case {

	public static void main(String[] args) {
		
		// Dependiendo del mes nos diga cuantos dias tiene
		int mes = 11;
		
		int dias = switch(mes) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12: 
				yield 30;   // Novedades en java 11-17  retorna el valor 30

			case 2:
				yield 28;
			case 4:
			case 6:
			case 9:
			case 11:
				yield 31;
			default:
				throw new RuntimeException("Ese mes no existe");
		};
		
		System.out.println("El mes " + mes + " tiene " + dias + " dias");

	}

}
