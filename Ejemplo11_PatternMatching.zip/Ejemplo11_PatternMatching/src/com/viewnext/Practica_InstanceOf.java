package com.viewnext;

import java.util.Scanner;

public class Practica_InstanceOf {

	public static void main(String[] args) {
		// Solicitar un dato al usuario por teclado
		// decir si es texto, numero entero, numero real, char, boolean
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un dato: ");
		Object dato = sc.next();  // "76"
		
		if (dato instanceof String texto) {
			System.out.println("El dato introducido " + texto + " es un texto");
		} else if (dato instanceof Integer i) {
			System.out.println("El dato introducido " + i + " es un numero entero");
		} else if (dato instanceof Double d) {
			System.out.println("El dato introducido " + d + " es un numero real");
		} else if (dato instanceof Character caracter) {
			System.out.println("El dato introducido " + caracter + " es un caracter");
		} else if (dato instanceof Boolean b) {
			System.out.println("El dato introducido " + b + " es un booleano");
		} else {
			System.out.println("Dato de otro tipo");
		}

	}

}
