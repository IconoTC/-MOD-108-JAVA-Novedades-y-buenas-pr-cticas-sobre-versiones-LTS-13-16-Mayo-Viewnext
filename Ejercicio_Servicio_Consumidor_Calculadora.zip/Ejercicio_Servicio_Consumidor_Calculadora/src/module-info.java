module com.viewnext.ejercicio.consumidor {
	
	requires com.viewnext.ejercicio.servicio;
	uses com.viewnext.interfaz.ItfzCalculadora;
	
}