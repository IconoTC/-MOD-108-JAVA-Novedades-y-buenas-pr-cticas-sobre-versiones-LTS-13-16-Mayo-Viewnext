package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo2_TareaAsincrona {

	public static void main(String[] args) {
		
		// Todo lo que indiquemos en este metodo se ejecuta en un hilo aparte
		CompletableFuture<Void> cFuture = CompletableFuture.runAsync(() -> {
			for(int i=1; i<=10; i++) {
				System.out.println("Tarea asincrona " + i);
			}
		});
		
		// Cuando finalice la tarea asincrona ejecutara la tarea del metodo thenRun
		cFuture.thenRun(() -> System.out.println("Tarea finalizada"));

	}

}
