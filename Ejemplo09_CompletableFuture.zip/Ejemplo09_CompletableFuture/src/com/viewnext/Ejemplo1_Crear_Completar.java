package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo1_Crear_Completar {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		CompletableFuture<String> completableFuture = new CompletableFuture<>();
		completableFuture.complete("Esto es una prueba");
		completableFuture.thenAccept(resultado -> System.out.println(resultado));
		completableFuture.thenAccept(System.out::println);

	}

}
