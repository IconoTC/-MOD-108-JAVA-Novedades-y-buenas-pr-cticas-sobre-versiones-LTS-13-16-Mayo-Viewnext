module  com.viewnext.ejemplo20 {
	
	// exports paquete
	exports com.viewnext.models;
	
}