module com.viewnext.ejercicio.proveedor {
	
	requires com.viewnext.ejercicio.servicio;
	provides com.viewnext.interfaz.ItfzCalculadora with com.viewnext.business.Calculadora;
	
}