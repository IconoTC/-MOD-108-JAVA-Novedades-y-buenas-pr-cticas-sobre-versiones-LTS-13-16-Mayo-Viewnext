module Ejercicio_Uso_Modulos {
	
	requires Ejercicio_Modulos;
}