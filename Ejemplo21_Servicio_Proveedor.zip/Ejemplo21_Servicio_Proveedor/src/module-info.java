module com.viewnext.proveedor {
	
	// Necesitamos el modulo donde esta declarada la interface
	requires com.viewnext.servicio;
	
	// proporcionar la clase que implementa la interface
	provides com.viewnext.interfaz.ItfzSaludo with com.viewnext.business.Saludo;
	
}