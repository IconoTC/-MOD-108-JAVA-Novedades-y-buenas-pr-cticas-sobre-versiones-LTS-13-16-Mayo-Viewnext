module Ejemplo20_Usar_Modulo {
	
	// Para poder usar el modulo de otro proyecto
	// Es agrgarlo como dependencia en el build path
	
	// requires nombre_modulo
	requires com.viewnext.ejemplo20;
}