package com.viewnext;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Practica {

	public static void main(String[] args) {
		
		// Lincon nace el 12 de feberero de 1809
		// Muere el 15 de abril de 1855
		LocalDate nacimiento = LocalDate.of(1809, Month.FEBRUARY, 12);
		LocalDate fallecimiento = LocalDate.of(1855, Month.APRIL, 15);
		
		// Cuantos años tenia cuando murio?
		System.out.println("Lincon murio con " + 
				nacimiento.until(fallecimiento, ChronoUnit.YEARS)  + " años");
		
		System.out.println("Lincon murio con " + 
				Period.between(nacimiento, fallecimiento).getYears()  + " años");
		
		// Cuantos dias vivio?
		System.out.println("Cuantos dias vivio " + 
				nacimiento.until(fallecimiento, ChronoUnit.DAYS)  + " dias");
		
		System.out.println("Cuantos dias vivio " + 
				Period.between(nacimiento, fallecimiento)  + " dias");
		
		// Si el año en que nacio era bisiesto o no
		System.out.println("Era bisiesto cuando nacio? " + nacimiento.isLeapYear());
		
		// Cuantas decadas han transcurrido desde su fallecimiento
		System.out.println("Cuantas decadas? " + 
				fallecimiento.until(LocalDate.now(), ChronoUnit.DECADES));
		
		// Que dia de la semana nacio
		System.out.println("Dia de nacimiento: " + nacimiento.getDayOfWeek());
		
		// Que dia de la semana fue su 30 cumpleaños
		System.out.println("Dia de 30 cumpleaños: " + nacimiento.plusYears(30).getDayOfWeek());
		System.out.println("Dia de 30 cumpleaños: " + nacimiento.withYear(30).getDayOfWeek());
	}

}
