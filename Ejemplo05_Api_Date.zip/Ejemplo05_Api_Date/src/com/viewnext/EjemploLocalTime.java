package com.viewnext;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemploLocalTime {

	public static void main(String[] args) {

		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);

		// Solo horas:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));

		// Tenemos concierto a las 22:30
		LocalTime concierto = LocalTime.of(22, 30);

		// Cuantas horas quedan para el concierto
		System.out.println(
				"Cuantas horas quedan para el concierto: " + 
						ahora.until(concierto, ChronoUnit.HOURS) + " horas");

		// Cuantos minutos quedan para el concierto
		System.out.println("Cuantos minutos quedan para el concierto: " + 
				ahora.until(concierto, ChronoUnit.MINUTES)
				+ " minutos");
		
		System.out.println(ahora.toSecondOfDay() + " segundos");
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");

	}

}
