package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import com.viewnext.models.Producto;

public class AppMain {
	
	// El filtro que recibe el metodo es un closure porque estoy recibiendo una funcion anonima
	public static List<Producto> filtrarProductos(List<Producto> lista, Predicate<Producto> filtro){
		List<Producto> listaNueva = new ArrayList<Producto>();
		for (Producto p : lista) {
			if (filtro.test(p)) {
				listaNueva.add(p);
			}
		}
		return listaNueva;
	}

	public static void main(String[] args) {
		
		List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 37.50),
			new Producto(3, "Raton", 18.75),
			new Producto(4, "Scanner", 400),
			new Producto(5, "Impresora", 110)
		);
		
		List<Producto> mas100 = filtrarProductos(lista, new Predicate<Producto>() {
			
			@Override
			public boolean test(Producto prod) {
				return prod.getPrecio() > 100;
			}
		});
		
		mas100.forEach(System.out::println);

	}

}
