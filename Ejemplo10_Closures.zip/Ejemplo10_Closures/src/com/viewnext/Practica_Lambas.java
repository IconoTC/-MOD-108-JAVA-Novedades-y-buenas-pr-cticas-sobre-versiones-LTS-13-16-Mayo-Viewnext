package com.viewnext;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.viewnext.models.Producto;

public class Practica_Lambas {
	
	// El filtro que recibe el metodo es un closure porque estoy recibiendo una funcion anonima
	public static List<Producto> filtrarProductos(List<Producto> lista, Predicate<Producto> filtro){	
		return lista.stream()
				.filter(filtro)
				.collect(Collectors.toList());
	}

	public static void main(String[] args) {
		
		List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 37.50),
			new Producto(3, "Raton", 18.75),
			new Producto(4, "Scanner", 400),
			new Producto(5, "Impresora", 110)
		);
		
		List<Producto> mas100 = filtrarProductos(lista, prod -> prod.getPrecio() > 100 );
		mas100.forEach(System.out::println);
		System.out.println("------------------");
		
		filtrarProductos(lista, prod -> prod.getPrecio() < 50)
			.forEach(System.out::println);
		System.out.println("------------------");
		
		filtrarProductos(lista, prod -> prod.getDescripcion().length() > 6)
			.forEach(System.out::println);
		System.out.println("------------------");
			

	}

}
