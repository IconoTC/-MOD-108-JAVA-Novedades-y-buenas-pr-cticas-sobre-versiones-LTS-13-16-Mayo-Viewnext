package com.viewnext;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		
		// Contenedor cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		
		// Enviar la peticion
		
		
		// Procesar la respuesta

	}

}
