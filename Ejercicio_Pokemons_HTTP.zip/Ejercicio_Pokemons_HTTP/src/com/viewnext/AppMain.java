package com.viewnext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws Exception{
		
		String url = "https://pokeapi.co/api/v2/pokemon/";
		
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		HttpClient cliente = HttpClient.newHttpClient();
		
		HttpResponse<String> respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());
		
		JSONObject jsonObject = new JSONObject(respuesta.body());
		JSONArray jsonArray = new JSONArray(jsonObject.get("results").toString());
		
		System.out.println("----- Lista de pokemons -----");
		for (Object object : jsonArray) {
			JSONObject jsonPokemon = new JSONObject(object.toString());
			System.out.println(jsonPokemon.getString("name"));		
		}
		System.out.println("----------------------------");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre del pokemon: ");
		String nombre = sc.next();
		
		String urlPokemon = url + nombre;
		uri = new URI(urlPokemon);
		request = HttpRequest.newBuilder(uri).GET().build();
		respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());
		JSONObject json = new JSONObject(respuesta.body());
		
		System.out.println("ID: " + json.getInt("id"));
		System.out.println("Nombre: " + json.getString("name"));
		System.out.println("Order: " + json.getInt("order"));
		System.out.println("Altura: " + json.getInt("height"));
		System.out.println("Peso: " + json.getInt("weight"));
		System.out.println("Habilidades:");
		JSONArray habilidades = new JSONArray(json.get("abilities").toString());
		for (Object object : habilidades) {
			JSONObject jsonHabilidad = new JSONObject(object.toString());
			JSONObject habilidad = new JSONObject(jsonHabilidad.get("ability").toString());
			System.out.print(habilidad.get("name") + "\t");
		}
		System.out.println();

	}

}
