package com.viewnext;

import com.viewnext.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un lambda al ser interface funcional
		ItfzMetodos lambda = () -> System.out.println("Hola, que tal?");
		lambda.prueba();
		
		// Podemos invocar a los metodos estaticos
		ItfzMetodos.estatico();
		
		// Los metodos default son dinamicos y necesitariamos una instancia de la interface
		new ItfzMetodos() {
			
			@Override
			public void prueba() {
				// TODO Auto-generated method stub
				
			}
		};
		
		// Los lambdas son instancias anonimas de la interface
		lambda.defecto();
		System.out.println(lambda.procesarTexto("Esto es una prueba"));
		
		// los metodos privados de la interface no son accesibles
		//lambda.mayusculas(".....");

	}

}
