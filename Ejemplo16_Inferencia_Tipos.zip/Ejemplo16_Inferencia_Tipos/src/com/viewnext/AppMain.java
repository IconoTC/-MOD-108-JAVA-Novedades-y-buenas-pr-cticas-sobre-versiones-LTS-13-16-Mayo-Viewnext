package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AppMain {
	
	// No funciona con variables globales o propiedades
	// Solo funciona con variables locales
	//var a = 25;

	public static void main(String[] args) {
		
		// No ponemos el tipo de dato
		// Utilizamos la palabra var para declarar variables
		// El tipo sera inferido en funcion del valor que asignemos
		// Una vez inferido un tipo no se puede cambiar
		
		var dato = 67;   // es de tipo entero
		//dato = "Hola caracola";   // Error, porque la variable es numerica
		dato = 1000;
		
		// Es obligatorio pasar un valor para inferir el tipo
		//var otra;
		//var mas = null;
		
		// Tampoco funciona si declaramos varias variables en la misma linea
		//var a, b = 7;
		//var a=2, b=8;
		
		
		// En arrays funciona dependiendo de como se declaren
		//var letras[] = {'a', 'e', 'i', 'o', 'u'};  // Error
		var letras = new char[]{'a', 'e', 'i', 'o', 'u'};
		var letras2 = new char[10];
		
		// En colecciones funciona
		var lista = new ArrayList<>();   // lista de objetos
		var lista2 = new ArrayList<Integer>();  // lista de enteros
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));   // lista con 5 numeros enteros
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5)); // lista con 5 numeros enteros
		
		var set = new HashSet<>();  // conjunto de objetos
		var set2 = new HashSet<String>();   // conjunto de cadenas
		var set3 = new HashSet<String>(Arrays.asList("Juan", "Maria", "Pedro")); // conjunto con 3 nombres
		var set4 = new HashSet<>(Arrays.asList("Juan", "Maria", "Pedro")); // conjunto con 3 nombres
		
		Map<String, Double> alumnos = new HashMap<>();
		//var alumnos = new HashMap<>();
		alumnos.put("Jorge", 9.8);
		alumnos.put("Miguel", 3.7);
		alumnos.put("Rocio", 6.2);
		alumnos.put("Alba", 8.5);
		
		var alumnos1 = new HashMap<>(); // Map<Object, Object>
		var alumnos2 = new HashMap<String, Double>();
		var alumnos3 = new HashMap<String, Double>(alumnos);  // var alumnos daria error
		var alumnos4 = new HashMap<>(alumnos);
		
		
		// Crear un bucle que muestre los numeros del 1 al 10 con inferencia de tipos
		for(var num = 1; num <= 10; num++) {
			System.out.println(num);
		}
		
		// Recorrer el array de letras creado en la linea 37
		for(var letra : letras) {
			System.out.println(letra);
		}
		
		
		

	}

}
