/**
 * 
 */
/**
 * 
 */
module Ejemplo16_Inferencia_Tipos {
}