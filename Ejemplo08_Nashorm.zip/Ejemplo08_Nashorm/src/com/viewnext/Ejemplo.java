package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Ejemplo {

	public static void main(String[] args) throws ScriptException {
		
		// Obtener una instancia del motor de JavaScript (ScriptEngine) 
		// a través de la clase ScriptEngineManager:
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorn = manager.getEngineByName("nashorn");
		
		// Evaluar código JavaScript utilizando el método eval() del motor de JavaScript:
		nashorn.eval("print('Hola Mundo')");
		
		// Pasar objetos Java al motor de JavaScript y acceder a sus propiedades y métodos:
		Persona p = new Persona();
		p.setNombre("María");
		nashorn.put("persona", p);
		nashorn.eval("print(persona.getNombre())");
		
		// Cargar y ejecutar scripts JavaScript desde archivos:
		nashorn.eval("load('src/hola.js')");

	}

}
