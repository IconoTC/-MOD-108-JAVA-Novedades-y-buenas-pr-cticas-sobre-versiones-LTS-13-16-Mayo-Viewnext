/**
 * 
 */
/**
 * 
 */
module Ejemplo12_ConstantesJVM {
}