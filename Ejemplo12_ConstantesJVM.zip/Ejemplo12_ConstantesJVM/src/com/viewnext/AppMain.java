package com.viewnext;

import java.lang.constant.ClassDesc;
import java.lang.constant.MethodTypeDesc;

public class AppMain {

	public static void main(String[] args) {
				
		// Creamos un descriptor de clase para java.util.ArrayList
		ClassDesc clase = ClassDesc.of("java.util", "ArrayList");
		System.out.println("Nombre: " + clase.displayName());  // ArrayList
		System.out.println("Paquete: " + clase.packageName());  // java.util
		System.out.println("Descriptor de clase: " + clase.descriptorString()); // Ljava/util/ArrayList;
		
		// Crear un descriptor de tipo de metodo
		//MethodTypeDesc.of(tipo_retorno, tipo_parametro1, tipo_parametro2,.....)
		// Crear un descriptor de metodo que no recibe ningun parametro y retorna un String
		MethodTypeDesc metodoString = MethodTypeDesc.of(ClassDesc.of("java.lang.String"));
		System.out.println(metodoString); // [()String]
		
		// Crear un descriptor de tipo de metodo que recibe un entero y retorna un double
		MethodTypeDesc metodoInt = MethodTypeDesc.of(ClassDesc.of("java.lang.Double"), ClassDesc.of("java.lang.Integer"));
		System.out.println(metodoInt);
   

	}
}