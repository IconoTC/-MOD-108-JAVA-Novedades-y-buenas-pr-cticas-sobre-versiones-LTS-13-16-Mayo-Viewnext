package com.viewnext;

import java.lang.constant.ClassDesc;
import java.lang.constant.MethodTypeDesc;

public class AppMain {

	public static void main(String[] args) {
		
		ClassDesc clase = ClassDesc.of("java.util", "ArrayList");
		MethodTypeDesc methodTypeDesc = MethodTypeDesc.of("java.lang.String");

	}
}