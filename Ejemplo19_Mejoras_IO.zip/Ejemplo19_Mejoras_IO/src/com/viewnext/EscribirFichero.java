package com.viewnext;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirFichero {

	public static void main(String[] args) {
		
		// Los recursos que se abren dentro de los parentesis del try
		// y ademas son AutoCloseables, se cierran solos
		// No es necesario invocar al metodo close
		try (FileWriter fichero = new FileWriter("datos.txt"); 
			 BufferedWriter buffer = new BufferedWriter(fichero);){
			
			// Escribir contenido en el fichero
			buffer.write("Hola, que tal?");
			buffer.write("\n");
			buffer.write("Por fin es jueves");
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
