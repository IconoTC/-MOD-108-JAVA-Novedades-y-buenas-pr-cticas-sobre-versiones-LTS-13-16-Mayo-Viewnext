package com.viewnext;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.viewnext.models.Persona;

public class DeserializarObjetos {

	public static void main(String[] args) {
		
		try (FileInputStream fichero = new FileInputStream("persona.ser");
			 ObjectInputStream inputStream = new ObjectInputStream(fichero);){
			
			Persona recuperada = (Persona) inputStream.readObject();
			
			System.out.println("Nombre: " + recuperada.getNombre());
			System.out.println("Edad: " + recuperada.getEdad());
			
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
