package com.viewnext;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.viewnext.models.Persona;

public class SerializarObjetos {

	public static void main(String[] args) {
		
		Persona persona = new Persona("Pepito", 37);
		
		try (FileOutputStream fichero = new FileOutputStream("persona.ser");
			 ObjectOutputStream outputStream = new ObjectOutputStream(fichero)){
			
			// Serializacion
			outputStream.writeObject(persona);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
