module com.viewnext.servicio {
	
	exports com.viewnext.interfaz;
}