package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args)  {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto que ya existe
		System.out.println(dao.buscarProducto(3));
		System.out.println(dao.buscarProducto(3).get());
		
		// Buscar un producto que NO EXISTE
		System.out.println(dao.buscarProducto(36543455));   // Optional.empty
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscarProducto(36543455).get());
		
		// Primera forma de evitar excepciones
		System.out.println(dao.buscarProducto(36543455).orElse(new Producto()));
		
		// Segunda forma de evitar excepciones
		Optional<Producto> opProducto = dao.buscarProducto(36543455);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Ese producto no existe");
		}
		
		if (opProducto.isEmpty()) {
			System.out.println("Ese producto no existe");
		} else {
			System.out.println(opProducto.get());
		}
		
		
		// Si el producto no existe lanzo una excepcion
		// java.util.NoSuchElementException: No value present
		//System.out.println(dao.buscarProducto(36543455).orElseThrow());
		
		// java.lang.RuntimeException: ERROR: producto con id 6
		System.out.println(dao.buscarProducto(6).orElseThrow());
		
		Optional<Producto> opProducto2 = dao.buscarProducto(5);
		opProducto2.ifPresent(System.out::println);
		

	}

}
