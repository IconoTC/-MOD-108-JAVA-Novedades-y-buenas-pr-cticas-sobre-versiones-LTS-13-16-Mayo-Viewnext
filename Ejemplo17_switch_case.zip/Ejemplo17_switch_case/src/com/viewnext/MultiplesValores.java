package com.viewnext;

import java.util.Scanner;

public class MultiplesValores {

	public static void main(String[] args) {
		// Solicitar al usuario un numero 0-10
		// Mostrar a que nota corresponde
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce numero 0-10: ");
		int nota = sc.nextInt();
		
		String resultado = switch (nota) {
			case 0,1,2,3,4 -> "Suspenso";
			case 5 -> "Aprobado";
			case 6 -> "Bien";
			case 7,8 -> "Notable";
			case 9,10 -> "Sobresaliente";
			default -> throw new IllegalArgumentException("Nota no valida: " + nota);
		};
		
		System.out.println("El resultado de tu examen es " + resultado);

	}

}
