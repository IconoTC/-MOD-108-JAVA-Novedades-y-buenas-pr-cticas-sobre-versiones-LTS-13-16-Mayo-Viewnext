package com.viewnext;

public class PatronType {

	public static void main(String[] args) {
		
		// El patron type en switch lo que hace es efectuar
		// el casting automatico en funcion del tipo de dato recibido
		
		Object dato = 123F;
		
		String formato = switch (dato) {
			case Integer entero -> String.format("int %d", entero);
			case Double real -> String.format("int %.1f", real);
			case Long enteroLong -> String.format("int %d", enteroLong);
			case Float realFloat -> String.format("int %.2f", realFloat);
			default -> dato.toString();
		};
		
		System.out.println(formato);

	}

}
