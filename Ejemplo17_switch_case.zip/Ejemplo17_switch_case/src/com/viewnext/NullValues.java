package com.viewnext;

public class NullValues {

	public static void main(String[] args) {
		
		Object dato = null;
		
		String formato = switch (dato) {
		case Integer entero -> String.format("int %d", entero);
		case Double real -> String.format("int %.1f", real);
		case Long enteroLong -> String.format("int %d", enteroLong);
		case Float realFloat -> String.format("int %.2f", realFloat);
		case null -> "Valor nulo";  // Acepta valores nulos
		default -> dato.toString();
	};
	
	System.out.println(formato);

	}

}
