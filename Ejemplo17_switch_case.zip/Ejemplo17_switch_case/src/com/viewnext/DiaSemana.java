package com.viewnext;

import java.util.Scanner;

public class DiaSemana {

	public static void main(String[] args) {
		// Solicitar al usuario una letra mayuscula
		// utilizando switch-case decir a que dia de la semana corresponde
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce dia de la semana (mayusculas): ");
		String dia = sc.next();
		
		switch (dia) {
			case "L" -> System.out.println("Es lunes");
			case "M" -> System.out.println("Es martes");
			case "X" -> System.out.println("Es miercoles");
			case "J" -> System.out.println("Es jueves");
			case "V" -> System.out.println("Es viernes");
			case "S" -> System.out.println("Es sabado");
			case "D" -> System.out.println("Es domingo");
			default ->  System.out.println("Dia desconocido");
		}

	}

}
