package com.viewnext;

public class PatronGuarded {
	
	// El patron guarded hace una combinacion del patron pattern y una expresion booleana
	// case Tipo variable && condicion

	public static void main(String[] args) {
		// ir probando con diferentes PW
		// pW -> valido: true/false
		System.out.println("789 valido: "  + validarPW(789));
		System.out.println("abc valido: "  + validarPW("abc"));

	}
	
	static boolean validarPW(Object dato) {
		// El PW es valido:
		// Si son numeros, minimo tienen que ser 6
		// Si es texto, tiene que tener al menos 1 numero
		// Si es texto, no puede comenzar por el numero
		// Si es texto, minimo 8 caracteres
		
		return switch(dato){
			case Integer i && i >= 100000 -> true;
			//case String texto && texto.contains("0123456789") -> true;
			//case String texto && texto.charAt(0) != 0  -> true;
			case String s && (s.length() >= 8) -> true;
			default -> false;
		};
		
		
	}

}
